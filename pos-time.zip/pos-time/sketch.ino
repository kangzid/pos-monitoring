#define START1 13
#define STOP1 12

#define START2 14
#define STOP2 27

#define START3 26
#define STOP3 25

#define START4 33
#define STOP4 32

#define START5 23
#define STOP5 22

void setup() {

  Serial.begin(115200);

  pinMode(START1, INPUT_PULLUP);
  pinMode(STOP1, INPUT_PULLUP);

  pinMode(START2, INPUT_PULLUP);
  pinMode(STOP2, INPUT_PULLUP);

  pinMode(START3, INPUT_PULLUP);
  pinMode(STOP3, INPUT_PULLUP);

  pinMode(START4, INPUT_PULLUP);
  pinMode(STOP4, INPUT_PULLUP);

  pinMode(START5, INPUT_PULLUP);
  pinMode(STOP5, INPUT_PULLUP);

  Serial.println("SYSTEM READY");
}

void loop() {

  // ================= POS 1 =================

  if (digitalRead(START1) == LOW) {
    Serial.println("POS1 START");

    while(digitalRead(START1) == LOW){
      delay(10);
    }
  }

  if (digitalRead(STOP1) == LOW) {
    Serial.println("POS1 STOP");

    while(digitalRead(STOP1) == LOW){
      delay(10);
    }
  }

  // ================= POS 2 =================

  if (digitalRead(START2) == LOW) {
    Serial.println("POS2 START");

    while(digitalRead(START2) == LOW){
      delay(10);
    }
  }

  if (digitalRead(STOP2) == LOW) {
    Serial.println("POS2 STOP");

    while(digitalRead(STOP2) == LOW){
      delay(10);
    }
  }

  // ================= POS 3 =================

  if (digitalRead(START3) == LOW) {
    Serial.println("POS3 START");

    while(digitalRead(START3) == LOW){
      delay(10);
    }
  }

  if (digitalRead(STOP3) == LOW) {
    Serial.println("POS3 STOP");

    while(digitalRead(STOP3) == LOW){
      delay(10);
    }
  }

  // ================= POS 4 =================

  if (digitalRead(START4) == LOW) {
    Serial.println("POS4 START");

    while(digitalRead(START4) == LOW){
      delay(10);
    }
  }

  if (digitalRead(STOP4) == LOW) {
    Serial.println("POS4 STOP");

    while(digitalRead(STOP4) == LOW){
      delay(10);
    }
  }

  // ================= POS 5 =================

  if (digitalRead(START5) == LOW) {
    Serial.println("POS5 START");

    while(digitalRead(START5) == LOW){
      delay(10);
    }
  }

  if (digitalRead(STOP5) == LOW) {
    Serial.println("POS5 STOP");

    while(digitalRead(STOP5) == LOW){
      delay(10);
    }
  }
}