#include <Arduino.h>

void setup()
{

    Serial.begin(115200);

    pinMode(13, INPUT_PULLUP);
    pinMode(12, INPUT_PULLUP);

    Serial.println("SYSTEM READY");
}

void loop()
{

    if (digitalRead(13) == LOW)
    {

        Serial.println("START");

        delay(200);
    }

    if (digitalRead(12) == LOW)
    {

        Serial.println("STOP");

        delay(200);
    }
}